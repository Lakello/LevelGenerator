﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LevelGenerator")]
